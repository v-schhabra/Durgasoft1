﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.VisualStudio.Services.ServiceEndpoints.WebApi;
using Microsoft.VisualStudio.ExternalProviders.Common;
using Newtonsoft.Json.Linq;
using Microsoft.VisualStudio.Services.OAuth;
using System.Xml.Linq;
using System.ComponentModel;



